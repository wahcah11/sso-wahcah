#!/bin/sh
LOG_FILE="/var/log/freeradius/auth_script.log"

echo "---" >> $LOG_FILE
echo "Script started via PAM at $(date)" >> $LOG_FILE

# BACA DARI ENVIRONMENT VARIABLES (PAM_USER, PAM_AUTHTOK)
USER_NAME="$PAM_USER"
USER_PASS="$PAM_AUTHTOK"

echo "Received User-Name: $USER_NAME" >> $LOG_FILE
echo "Received User-Password: [REDACTED]" >> $LOG_FILE

HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
    -X POST -H "Content-Type: application/json" \
    -d "{\"User-Name\": \"$USER_NAME\", \"User-Password\": \"$USER_PASS\"}" \
    http://radius-bridge:5000/authenticate)

echo "Curl finished with HTTP status: $HTTP_STATUS" >> $LOG_FILE

if [ "$HTTP_STATUS" -eq 200 ]; then
    echo "Result: Success (Exit 0)" >> $LOG_FILE
    exit 0
else
    echo "Result: Failure (Exit 1)" >> $LOG_FILE
    exit 1
fi