services:
  postgres:
    image: postgres:15-alpine
    container_name: sso_postgres
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      POSTGRES_DB: ${POSTGRES_DB}
      POSTGRES_USER: ${POSTGRES_USER}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    restart: unless-stopped
    networks:
      - sso_network

  keycloak:
    # --- MENGGUNAKAN VERSI YANG ANDA MINTA ---
    image: quay.io/keycloak/keycloak:26.3.2
    # ----------------------------------------
    container_name: sso_keycloak
    depends_on:
      - postgres
    environment:
      KC_DB: postgres
      KC_DB_URL_HOST: postgres
      KC_DB_URL_DATABASE: ${POSTGRES_DB}
      KC_DB_USERNAME: ${POSTGRES_USER}
      KC_DB_PASSWORD: ${POSTGRES_PASSWORD}
      KEYCLOAK_ADMIN: ${KEYCLOAK_ADMIN_USER}
      KEYCLOAK_ADMIN_PASSWORD: ${KEYCLOAK_ADMIN_PASS}
    ports:
      - "8080:8080"
    command: start-dev
    restart: unless-stopped
    networks:
      - sso_network

  radius-bridge:
    build:
      context: ./radius-bridge
    container_name: sso_radius_bridge
    restart: unless-stopped
    networks:
      - sso_network
    depends_on:
      - keycloak

  freeradius:
    build:
      context: ./freeradius-build
    container_name: sso_freeradius
    ports:
      - "1812:1812/udp"
      - "1813:1813/udp"
    volumes:
      - ./freeradius-build/freeradius-config/mods-available/rest:/etc/freeradius/3.0/mods-available/rest
      - ./freeradius-build/freeradius-config/sites-available/default:/etc/freeradius/3.0/sites-available/default
    depends_on:
      - radius-bridge
    restart: unless-stopped
    networks:
      - sso_network

volumes:
  postgres_data:
    driver: local

networks:
  sso_network:
    driver: bridge